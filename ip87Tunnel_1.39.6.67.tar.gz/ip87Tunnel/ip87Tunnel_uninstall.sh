#!/bin/bash

cd /etc/init.d
update-rc.d -f ip87Tunneld remove
rm -f ip87Tunneld

