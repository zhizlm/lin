#!/bin/bash

pwd > mypath
sed -e 's/\//\\\//g' mypath > mypath1
script='s/APP_EXEC_DIR/'`cat mypath1`'/'
sed -e $script ip87Tunneld > /etc/init.d/ip87Tunneld
rm -f mypath mypath1

cd /etc/init.d
chmod 755 ip87Tunneld
update-rc.d ip87Tunneld defaults 98


